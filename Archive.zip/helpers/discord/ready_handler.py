async def on_ready_handler(bot):
    print(f'We have logged in as {bot.user}')
