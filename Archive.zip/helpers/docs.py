
def generate_dummy(type:str):
    if type == 'socmed_id':
        return '1317625977'
    elif type == 'user_id':
        return 'fcd3f23e-e5aa-11ee-892a-3216422910e9'
    elif type == 'lat':
        return '-6.2333934867861975'
    elif type == 'long':
        return '106.82363788271587'
    elif type == 'search':
        return 'jakarta'
    elif type == 'pin_category':
        return 'friend'
    elif type == 'year':
        return 2024
    elif type == 'date':
        return '2024-09-13'
    elif type == 'email':
        return 'flazen.edu@gmail.com'
    elif type == 'username':
        return 'flazefy'
    elif type == 'token':
        return 'AWSEDR'
    
